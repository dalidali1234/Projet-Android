package com.example.myapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {
    public static final String DATABASE_NAME = "bdcircuits";
    SQLiteDatabase mDatabase;
    EditText eVilleDepart;
    EditText eVilleArivee;
    EditText ePrix;
    EditText eDuree;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        eVilleDepart = (EditText) findViewById(R.id.eVilleDepart);
        eVilleArivee = (EditText) findViewById(R.id.eVilleArivee);
        ePrix = (EditText) findViewById(R.id.ePrix);
        eDuree = (EditText) findViewById(R.id.eDuree);
        Button btnSave =(Button)findViewById(R.id.btnSave);
        mDatabase =openOrCreateDatabase(DATABASE_NAME, MODE_PRIVATE, null);

        createCircuitTable();
    }


    private void createCircuitTable() {
        mDatabase.execSQL(
                "CREATE TABLE IF NOT EXISTS circuits (\n" +
                        "    IdCircuit INTEGER NOT NULL CONSTRAINT circuit_pk PRIMARY KEY AUTOINCREMENT,\n" +
                        "    VilleDepart varchar(200) NOT NULL,\n" +
                        "    VilleArivee varchar(200) NOT NULL,\n" +
                        "    Duree int NOT NULL,\n" +
                        "    Prix double NOT NULL\n" +
                        ");"
        );
    }
    public void saveCircuit(View view) {
        String departV = eVilleDepart.getText().toString().trim();
        String arriveV = eVilleArivee.getText().toString().trim();
        String prix = ePrix.getText().toString().trim();
        String period= eDuree.getText().toString().trim();
        String insertSQL = "INSERT INTO circuits \n" +
                "(VilleDepart, VilleArivee, Duree, Prix)\n" +
                "VALUES \n" +
                "(?, ?, ?, ?);";

        //using the same method execsql for inserting values
        //this time it has two parameters
        //first is the sql string and second is the parameters that is to be binded with the query
        mDatabase.execSQL(insertSQL, new String[]{departV, arriveV, prix, period});

        Toast.makeText(this, "Circuit Added Successfully", Toast.LENGTH_SHORT).show();
    }
    public void ViewCircuit(View view) {
        startActivity(new Intent(this, CircuitListActivity.class));
    }
}
