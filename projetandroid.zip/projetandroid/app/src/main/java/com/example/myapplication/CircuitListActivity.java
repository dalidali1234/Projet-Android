package com.example.myapplication;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class CircuitListActivity extends AppCompatActivity {
    public static final String DATABASE_NAME = "bdcircuits";

    List<circuit> circuitListList;
    SQLiteDatabase mDatabase;
    ListView listViewCircuit;
    CircuitAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circuit_list);

        listViewCircuit = (ListView) findViewById(R.id.listViewCircuit);
        circuitListList = new ArrayList<>();

        //opening the database
        mDatabase = openOrCreateDatabase(DATABASE_NAME, MODE_PRIVATE, null);

        //this method will display the employees in the list
        showEmployeesFromDatabase();
    }

    private void showEmployeesFromDatabase() {
        Cursor cursorCircuit = mDatabase.rawQuery("SELECT * FROM circuits", null);

        //if the cursor has some data
        if (cursorCircuit.moveToFirst()) {
            //looping through all the records
            do {
                //pushing each record in the employee list
                circuitListList.add(new circuit(
                        cursorCircuit.getInt(0),
                        cursorCircuit.getString(1),
                        cursorCircuit.getString(2),
                        cursorCircuit.getDouble(3),
                        cursorCircuit.getInt(4)
                ));
            } while (cursorCircuit.moveToNext());
        }
        Toast.makeText(this,""+circuitListList.size(),Toast.LENGTH_LONG).show();
        //closing the cursor
        cursorCircuit.close();

        //creating the adapter object
        adapter = new CircuitAdapter(this, R.layout.list_layout_circuit,circuitListList, mDatabase);

        //adding the adapter to listview
        listViewCircuit.setAdapter((ListAdapter) adapter);
    }

}
