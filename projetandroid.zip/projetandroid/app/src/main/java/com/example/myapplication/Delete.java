package com.example.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class Delete extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
    }

    public class CircuitAdapter extends ArrayAdapter<circuit> {


        Context mCtx;
        int listLayoutRes;
        List<circuit> circuitList;
        SQLiteDatabase mDatabase;

        public CircuitAdapter(Context mCtx, int listLayoutRes, List<circuit> employeeList, SQLiteDatabase mDatabase) {
            super(mCtx, listLayoutRes, employeeList);

            this.mCtx = mCtx;
            this.listLayoutRes = listLayoutRes;
            this.circuitList = employeeList;
            this.mDatabase = mDatabase;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater inflater = LayoutInflater.from(mCtx);
            View view = inflater.inflate(listLayoutRes, null);

            final circuit circuit = circuitList.get(position);
            TextView textViewId = view.findViewById(R.id.textViewId);
            TextView textViewDept = view.findViewById(R.id.textViewDept);
            TextView textViewarrive = view.findViewById(R.id.textViewarrive);
            TextView textViewPrix = view.findViewById(R.id.textViewPrix);
            TextView textViewduree = view.findViewById(R.id.textViewduree);


            textViewId.setText(circuit.getIdCircuit()+"");
            textViewDept.setText(circuit.getVilleDepart());
            textViewarrive.setText(circuit.getVilleArrive());
            textViewduree.setText(circuit.getDuree()+"");
            textViewPrix.setText(circuit.getPrix()+"");

            Button buttonDelete = view.findViewById(R.id.buttonDeleteEmployee);
            Button buttonEdit = view.findViewById(R.id.buttonEditEmployee);

            //adding a clicklistener to button
            buttonEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    updateEmployee(circuit);
                }
            });

            //the delete operation
            buttonDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(mCtx);
                    builder.setTitle("Are you sure?");
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            String sql = "DELETE FROM circuits WHERE IdCircuit = ?";
                            mDatabase.execSQL(sql, new Integer[]{circuit.getIdCircuit()});
                            reloadEmployeesFromDatabase();
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            });

            return view;
        }

        private void updateEmployee(final circuit circuit) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(mCtx);
            LayoutInflater inflater = LayoutInflater.from(mCtx);
            View view = inflater.inflate(R.layout.dialog_update_circuit,null);
            builder.setView(view);
            final EditText editVilleD = view.findViewById(R.id.editvillea);
            final EditText editVille = view.findViewById(R.id.editvilled);
            final EditText editDate = view.findViewById(R.id.editDate);
            final EditText editPrix = view.findViewById(R.id.editPrix);
            final Button buttonUpdate=  view.findViewById(R.id.buttonUpdate);
            editVille.setText(circuit.getVilleDepart());
            editVilleD.setText(circuit.getVilleArrive());
            editDate.setText(circuit.getDuree()+"");
            editPrix.setText(circuit.getPrix()+"");

            final AlertDialog dialog = builder.create();
            dialog.show();

            buttonUpdate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String arrive = editVille.getText().toString().trim();
                    String depart = editVilleD.getText().toString().trim();
                    String durre = editDate.getText().toString().trim();
                    String prix = editPrix.getText().toString().trim();
                    if (depart.isEmpty()) {
                        editVille.setError("depart can't be blank");
                        editVille.requestFocus();
                        return;
                    }

                    if (arrive.isEmpty()) {
                        editVilleD.setError("arrivé can't be blank");
                        editVilleD.requestFocus();
                        return;
                    }

                    if (durre.isEmpty()) {
                        editDate.setError("durre can't be blank");
                        editDate.requestFocus();
                        return;
                    }
                    if (prix.isEmpty()) {
                        editPrix.setError("prix can't be blank");
                        editPrix.requestFocus();
                        return;
                    }
                    String sql = "UPDATE circuits \n" +
                            "SET VilleDepart = ?, \n" +
                            "VilleArivee = ?, \n" +
                            "Duree = ? ,\n" +
                            "Prix = ? \n" +
                            "WHERE IdCircuit = ?;\n";

                    mDatabase.execSQL(sql, new String[]{depart,arrive, durre,prix, String.valueOf(circuit.getIdCircuit())});
                    Toast.makeText(mCtx, "updated", Toast.LENGTH_SHORT).show();
                    reloadEmployeesFromDatabase();

                    dialog.dismiss();
                }
            });
        }

        private void reloadEmployeesFromDatabase() {
            Cursor cursorCircuits = mDatabase.rawQuery("SELECT * FROM circuits", null);
            if (cursorCircuits.moveToFirst()) {
                circuitList.clear();
                do {
                    circuitList.add(new circuit(
                            cursorCircuits.getInt(0),
                            cursorCircuits.getString(1),
                            cursorCircuits.getString(2),
                            cursorCircuits.getDouble(3),
                            cursorCircuits.getInt(4)
                    ));
                } while (cursorCircuits.moveToNext());
            }
            cursorCircuits.close();
            notifyDataSetChanged();
        }

    }
}
