package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnAjouter,btnSupprimer,btnRecherche;
    TextView txtView1,txtView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnAjouter = findViewById(R.id.btnAjouter);
        Button btnSupprimer = findViewById(R.id.btnSupprimer);
        Button btnModifier = findViewById(R.id.btnModifier);
        Button btnRechercher = findViewById(R.id.btnRecherche);

        btnAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentAjout = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intentAjout);
            }
        });
        btnSupprimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSupprime = new Intent(MainActivity.this, Delete.class);
                startActivity(intentSupprime);
            }
        });

        btnModifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentModify = new Intent(MainActivity.this, circuit.class);
                startActivity(intentModify);
            }
        });
    }
}
