package com.example.myapplication;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    public static final String DATABASE_NAME = "bdcircuits";
    SQLiteDatabase mDatabase;
    TextView textIdCircuit;
    EditText eIdCircuit;
    TextView textVilleDepart;
    EditText eVilleDepart;
    TextView textVilleArivee;
    EditText eVilleArivee;
    TextView textPrix;
    EditText ePrix;
    TextView texDuree;
    EditText eDuree;
    String VilleDepart, VilleArivee, Prix, Duree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        // bdcircuits = openOrCreateDatabase("bdcircuits", MODE_PRIVATE, null);
        //Create table bdcircuits
        // bdcircuits.execSQL("CREATE TABLE IF NOT EXISTS circuits (IdCircuit INTEGER PRIMARY KEY AUTOINCREMENT ,VilleDepart VARCHAR(255) ,VilleArivee VARCHAR(255),Prix REAL ,Duree INT);");
        // SQLiteStatement s = bdcircuits.compileStatement("select count(*) from circuits;");
        mDatabase = openOrCreateDatabase(DATABASE_NAME, MODE_PRIVATE, null);
        createCircuitTable();
        textVilleDepart = (TextView) findViewById(R.id.textVilleDepart);
        eVilleDepart = (EditText) findViewById(R.id.eVilleDepart);
        eVilleArivee = (EditText) findViewById(R.id.eVilleArivee);
        textVilleArivee = (TextView) findViewById(R.id.textVilleArivee);
        ePrix = (EditText) findViewById(R.id.ePrix);
        textPrix = (TextView) findViewById(R.id.textPrix);
        eDuree = (EditText) findViewById(R.id.eDuree);


    }
    private void createCircuitTable() {
        mDatabase.execSQL(
                "CREATE TABLE IF NOT EXISTS circuits (\n" +
                        "    IdCircuit INTEGER NOT NULL CONSTRAINT employees_pk PRIMARY KEY AUTOINCREMENT,\n" +
                        "    VilleDepart varchar(200) NOT NULL,\n" +
                        "    VilleArivee varchar(200) NOT NULL,\n" +
                        "    Duree int NOT NULL,\n" +
                        "    Prix double NOT NULL\n" +
                        ");"
        );
    }

    public void saveCircuit(View view) {
        String eId = eIdCircuit.getText().toString().trim();
        String departV = eVilleDepart.getText().toString().trim();
        String arriveV = eVilleArivee.getText().toString().trim();
        String prix = ePrix.getText().toString().trim();
        String period= eDuree.getText().toString().trim();
        String insertSQL = "INSERT INTO circuits \n" +
                "(VilleDepart, VilleArivee, Duree, Prix)\n" +
                "VALUES \n" +
                "(?, ?, ?, ?);";

        //using the same method execsql for inserting values
        //this time it has two parameters
        //first is the sql string and second is the parameters that is to be binded with the query
        mDatabase.execSQL(insertSQL, new String[]{departV, arriveV, prix, period});

        Toast.makeText(this, "Circuit Added Successfully", Toast.LENGTH_SHORT).show();
    }

}
