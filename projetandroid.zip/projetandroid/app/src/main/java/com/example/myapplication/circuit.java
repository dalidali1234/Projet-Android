package com.example.myapplication;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class circuit  extends AppCompatActivity {
    private int idCircuit;
    private String villeDepart;
    private String villeArrive;
    private double prix;
    private int duree;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circuit);

    }
    public circuit(int idCircuit, String villeDepart, String villeArrive, double prix, int duree) {
        this.idCircuit = idCircuit;
        this.villeDepart = villeDepart;
        this.villeArrive = villeArrive;
        this.prix = prix;
        this.duree = duree;
    }

    public circuit(String villeDepart, String villeArrive, Float prix,int duree) {
    }

    public int getIdCircuit() {
        return idCircuit;
    }

    public void setIdCircuit(int idCircuit) {
        this.idCircuit = idCircuit;
    }

    public String getVilleDepart() {
        return villeDepart;
    }

    public void setVilleDepart(String villeDepart) {
        this.villeDepart = villeDepart;
    }

    public String getVilleArrive() {
        return villeArrive;
    }

    public void setVilleArrive(String villeArrive) {
        this.villeArrive = villeArrive;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(Float prix) {
        this.prix = prix;
    }

    public int getDuree() {
        return duree;
    }

    public void setDuree(int duree) {
        this.duree = duree;
    }
}